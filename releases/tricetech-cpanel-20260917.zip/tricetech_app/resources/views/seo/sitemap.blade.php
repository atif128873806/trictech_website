{!! '<'.'?xml version="1.0" encoding="UTF-8"?>' !!}
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    @foreach ([route('home'), route('infrastructure'), route('cloud-software'), route('privacy')] as $url)
    <url><loc>{{ $url }}</loc></url>
    @endforeach
</urlset>
